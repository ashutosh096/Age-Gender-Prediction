# Age & Gender Predictor — AI Vision App

A deep learning web app that detects faces in uploaded photos and predicts **age range** and **gender** using pre-trained Caffe neural network models (OpenCV DNN backend).

## Model Details

| Model | Architecture | Training Data | Accuracy |
|-------|-------------|---------------|----------|
| Face Detector | ResNet-10 SSD | WIDER FACE | ~99% detection |
| Gender Model | GoogLeNet Caffe | Adience benchmark | ~91% |
| Age Model | GoogLeNet Caffe | Adience benchmark | ~6 yr MAE |

**Age Buckets:** (0-2), (4-6), (8-12), (15-20), (25-32), (38-43), (48-53), (60-100)

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Download pre-trained models (~90 MB total)
```bash
python setup.py
```

### 3. Run the app
```bash
python app.py
```

### 4. Open your browser
```
http://localhost:5000
```

## Project Structure

```
age_gender_app/
├── app.py              ← Flask backend + prediction logic
├── setup.py            ← Model downloader
├── requirements.txt
├── models/             ← Downloaded model files (auto-created)
│   ├── age_deploy.prototxt
│   ├── age_net.caffemodel
│   ├── gender_deploy.prototxt
│   ├── gender_net.caffemodel
│   ├── opencv_face_detector.pbtxt
│   └── opencv_face_detector_uint8.pb
├── templates/
│   └── index.html      ← Beautiful dark-themed UI
└── static/
    └── uploads/
```

## Features

- **Multi-face detection** — detects and analyses multiple faces in one photo
- **Confidence scores** — shows probability breakdown for all age buckets and both genders
- **Annotated output** — returns the image with bounding boxes and labels drawn
- **Drag & drop** — modern upload interface
- **Real-time** — fast CPU-based inference, no GPU needed

## Tips for Best Results

- Use clear, front-facing photos
- Good lighting improves accuracy significantly
- Avoid extreme angles or heavy occlusion
- Higher resolution photos give better results

## Tech Stack

- **Python 3** + **Flask** — backend server
- **OpenCV DNN** — deep neural network inference engine
- **Caffe models** — pre-trained age/gender Caffe models (Levi & Hassner, 2015)
- **Vanilla JS** — frontend with drag & drop, progress, confidence bars

## References

- Levi, G., & Hassner, T. (2015). Age and Gender Classification Using Convolutional Neural Networks. CVPR Workshops.
- [LearnOpenCV Age Gender Detection](https://learnopencv.com/age-gender-classification-using-opencv-deep-learning-c-python/)
