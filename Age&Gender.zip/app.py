import os
import cv2
import numpy as np
from flask import Flask, request, render_template, jsonify
from werkzeug.utils import secure_filename
import base64
import urllib.request

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = 'static/uploads'

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}

# ── Model URLs (OpenCV DNN — Adience benchmark, ~91% gender acc, ~6yr MAE) ──
MODELS = {
    "face_proto":   "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt",
    "face_model":   "https://github.com/opencv/opencv_extra/raw/master/testdata/dnn/opencv_face_detector_uint8.pb",
    "age_proto":    "https://raw.githubusercontent.com/GilLevi/AgeProgression/master/models/age_net.caffemodel.prototxt",  # fallback below
    "gender_proto": "https://raw.githubusercontent.com/GilLevi/AgeProgression/master/models/gender_net.caffemodel.prototxt",
}

# Official Caffe models from well-known CV repo
AGE_PROTO     = "models/age_deploy.prototxt"
AGE_MODEL     = "models/age_net.caffemodel"
GENDER_PROTO  = "models/gender_deploy.prototxt"
GENDER_MODEL  = "models/gender_net.caffemodel"
FACE_PROTO    = "models/opencv_face_detector.pbtxt"
FACE_MODEL    = "models/opencv_face_detector_uint8.pb"

AGE_BUCKETS = ['(0-2)', '(4-6)', '(8-12)', '(15-20)',
               '(25-32)', '(38-43)', '(48-53)', '(60-100)']
AGE_LABELS  = ['Infant\n0–2', 'Child\n4–6', 'Child\n8–12', 'Teen\n15–20',
               'Young Adult\n25–32', 'Adult\n38–43', 'Middle-Aged\n48–53', 'Senior\n60+']
GENDER_LIST = ['Male', 'Female']

MODEL_MEAN  = (78.4263377603, 87.7689143744, 114.895847746)

os.makedirs('models', exist_ok=True)

def download_models():
    """Download pre-trained Caffe models on first run."""
    files = {
        AGE_PROTO:    "https://raw.githubusercontent.com/spmallick/learnopencv/master/AgeGender/age_deploy.prototxt",
        AGE_MODEL:    "https://github.com/GilLevi/AgeProgression/raw/master/models/age_net.caffemodel",
        GENDER_PROTO: "https://raw.githubusercontent.com/spmallick/learnopencv/master/AgeGender/gender_deploy.prototxt",
        GENDER_MODEL: "https://github.com/GilLevi/AgeProgression/raw/master/models/gender_net.caffemodel",
        FACE_PROTO:   "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt",
        FACE_MODEL:   "https://github.com/opencv/opencv_extra/raw/master/testdata/dnn/opencv_face_detector_uint8.pb",
    }
    for path, url in files.items():
        if not os.path.exists(path):
            print(f"Downloading {path}...")
            try:
                urllib.request.urlretrieve(url, path)
                print(f"  ✓ {path}")
            except Exception as e:
                print(f"  ✗ Failed: {e}")

def load_networks():
    """Load DNN models into memory."""
    nets = {}
    try:
        nets['face']   = cv2.dnn.readNet(FACE_MODEL, FACE_PROTO)
        nets['age']    = cv2.dnn.readNet(AGE_MODEL,  AGE_PROTO)
        nets['gender'] = cv2.dnn.readNet(GENDER_MODEL, GENDER_PROTO)
        print("✓ All models loaded successfully")
    except Exception as e:
        print(f"⚠ Model load error: {e}")
        print("  → Run download_models() first or ensure model files exist.")
    return nets

def detect_faces(net, frame):
    """Detect faces using OpenCV DNN face detector."""
    h, w = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300),
                                  [104, 117, 123], swapRB=False)
    net.setInput(blob)
    detections = net.forward()
    faces = []
    for i in range(detections.shape[2]):
        confidence = detections[0, 0, i, 2]
        if confidence > 0.7:
            x1 = int(detections[0, 0, i, 3] * w)
            y1 = int(detections[0, 0, i, 4] * h)
            x2 = int(detections[0, 0, i, 5] * w)
            y2 = int(detections[0, 0, i, 6] * h)
            # Clamp to image bounds
            x1, y1 = max(0, x1), max(0, y1)
            x2, y2 = min(w, x2), min(h, y2)
            if x2 > x1 and y2 > y1:
                faces.append((x1, y1, x2, y2, float(confidence)))
    return faces

def predict_age_gender(nets, face_img):
    """Run age and gender prediction on a cropped face."""
    blob = cv2.dnn.blobFromImage(face_img, 1.0, (227, 227),
                                  MODEL_MEAN, swapRB=False)
    # Gender
    nets['gender'].setInput(blob)
    gender_preds = nets['gender'].forward()[0]
    gender_idx   = gender_preds.argmax()
    gender       = GENDER_LIST[gender_idx]
    gender_conf  = float(gender_preds[gender_idx])

    # Age
    nets['age'].setInput(blob)
    age_preds  = nets['age'].forward()[0]
    age_idx    = age_preds.argmax()
    age_bucket = AGE_BUCKETS[age_idx]
    age_conf   = float(age_preds[age_idx])

    # Build confidence breakdown for all age buckets
    age_breakdown = [
        {"label": AGE_BUCKETS[i], "prob": round(float(age_preds[i]) * 100, 1)}
        for i in range(len(AGE_BUCKETS))
    ]
    gender_breakdown = [
        {"label": GENDER_LIST[i], "prob": round(float(gender_preds[i]) * 100, 1)}
        for i in range(2)
    ]

    return {
        "gender":            gender,
        "gender_confidence": round(gender_conf * 100, 1),
        "gender_breakdown":  gender_breakdown,
        "age_bucket":        age_bucket,
        "age_confidence":    round(age_conf * 100, 1),
        "age_breakdown":     age_breakdown,
    }

def draw_results(frame, faces, predictions):
    """Draw bounding boxes and labels on the image."""
    annotated = frame.copy()
    for i, (x1, y1, x2, y2, conf) in enumerate(faces):
        pred = predictions[i]
        color = (42, 171, 116) if pred['gender'] == 'Female' else (52, 152, 219)
        cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
        label = f"{pred['gender']} {pred['age_bucket']}"
        conf_txt = f"G:{pred['gender_confidence']}% A:{pred['age_confidence']}%"
        (lw, lh), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
        cv2.rectangle(annotated, (x1, y1 - lh - 20), (x1 + max(lw, 200), y1), color, -1)
        cv2.putText(annotated, label,    (x1 + 4, y1 - lh - 4),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
        cv2.putText(annotated, conf_txt, (x1 + 4, y1 - 2),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.38, (255,255,255), 1)
    return annotated

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def img_to_base64(img):
    _, buf = cv2.imencode('.jpg', img, [cv2.IMWRITE_JPEG_QUALITY, 92])
    return base64.b64encode(buf).decode('utf-8')

# Load models at startup
download_models()
nets = load_networks()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    file = request.files['image']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({'error': 'Invalid file type. Use JPG, PNG, or WEBP.'}), 400

    if not nets:
        return jsonify({'error': 'Models not loaded. Run download_models() first.'}), 500

    try:
        img_bytes = np.frombuffer(file.read(), np.uint8)
        frame = cv2.imdecode(img_bytes, cv2.IMREAD_COLOR)
        if frame is None:
            return jsonify({'error': 'Could not decode image.'}), 400

        # Resize if too large (for speed)
        h, w = frame.shape[:2]
        if max(h, w) > 1200:
            scale = 1200 / max(h, w)
            frame = cv2.resize(frame, (int(w*scale), int(h*scale)))

        faces = detect_faces(nets['face'], frame)
        if not faces:
            return jsonify({'error': 'No face detected. Please use a clear front-facing photo.'}), 200

        predictions = []
        for (x1, y1, x2, y2, conf) in faces:
            pad = 20
            x1p = max(0, x1 - pad)
            y1p = max(0, y1 - pad)
            x2p = min(frame.shape[1], x2 + pad)
            y2p = min(frame.shape[0], y2 + pad)
            face_crop = frame[y1p:y2p, x1p:x2p]
            pred = predict_age_gender(nets, face_crop)
            pred['face_index'] = len(predictions) + 1
            predictions.append(pred)

        annotated = draw_results(frame, faces, predictions)
        annotated_b64 = img_to_base64(annotated)

        return jsonify({
            'success':     True,
            'face_count':  len(faces),
            'predictions': predictions,
            'annotated':   annotated_b64,
        })

    except Exception as e:
        return jsonify({'error': f'Prediction failed: {str(e)}'}), 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)
