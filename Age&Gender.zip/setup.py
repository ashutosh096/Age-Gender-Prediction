#!/usr/bin/env python3
"""
setup.py — Downloads all required pre-trained model files.
Run once before starting the app: python setup.py
"""
import os
import sys
import urllib.request

os.makedirs('models', exist_ok=True)

MODELS = [
    (
        "models/age_deploy.prototxt",
        "https://raw.githubusercontent.com/spmallick/learnopencv/master/AgeGender/age_deploy.prototxt",
        "Age network architecture"
    ),
    (
        "models/age_net.caffemodel",
        "https://github.com/GilLevi/AgeProgression/raw/master/models/age_net.caffemodel",
        "Age prediction weights (~44 MB)"
    ),
    (
        "models/gender_deploy.prototxt",
        "https://raw.githubusercontent.com/spmallick/learnopencv/master/AgeGender/gender_deploy.prototxt",
        "Gender network architecture"
    ),
    (
        "models/gender_net.caffemodel",
        "https://github.com/GilLevi/AgeProgression/raw/master/models/gender_net.caffemodel",
        "Gender prediction weights (~44 MB)"
    ),
    (
        "models/opencv_face_detector.pbtxt",
        "https://raw.githubusercontent.com/opencv/opencv/master/samples/dnn/face_detector/deploy.prototxt",
        "Face detector architecture"
    ),
    (
        "models/opencv_face_detector_uint8.pb",
        "https://github.com/opencv/opencv_extra/raw/master/testdata/dnn/opencv_face_detector_uint8.pb",
        "Face detector weights (~2.7 MB)"
    ),
]

def progress(count, block_size, total_size):
    pct = int(count * block_size * 100 / total_size) if total_size > 0 else 0
    pct = min(pct, 100)
    bar = '#' * (pct // 5) + '-' * (20 - pct // 5)
    sys.stdout.write(f'\r  [{bar}] {pct}%')
    sys.stdout.flush()

print("\n=== Age & Gender Predictor — Model Setup ===\n")
all_ok = True

for path, url, desc in MODELS:
    if os.path.exists(path):
        size_mb = os.path.getsize(path) / 1024 / 1024
        print(f"  ✓ {desc} already exists ({size_mb:.1f} MB)")
        continue

    print(f"\n  Downloading: {desc}")
    print(f"  URL: {url}")
    try:
        urllib.request.urlretrieve(url, path, reporthook=progress)
        print()
        size_mb = os.path.getsize(path) / 1024 / 1024
        print(f"  ✓ Saved to {path} ({size_mb:.1f} MB)")
    except Exception as e:
        print(f"\n  ✗ FAILED: {e}")
        all_ok = False

print("\n" + "="*44)
if all_ok:
    print("✓ All models ready! Run: python app.py")
    print("  Then open: http://localhost:5000")
else:
    print("⚠ Some downloads failed. Check your internet connection.")
print("="*44 + "\n")
